
import imp
_progressnotes = imp.load_dynamic("_progressnotes", "kf__progressnotes_fd8f9a7f.pyd")
from _progressnotes import *