import imp
_speedups = imp.load_dynamic("_speedups", "_speedups_fd8f9a7e.pyd")
from _speedups import *